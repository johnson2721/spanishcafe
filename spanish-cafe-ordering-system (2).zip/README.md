# ☕ SPANISH CAFE – Online Food Ordering System

> **Fresh • Affordable • Delicious**  
> A complete, production-ready, responsive online food ordering website for SPANISH CAFE.

---

## 🚀 Features

- 🎨 **Beautiful UI** – Warm restaurant colors (orange, cream, yellow, green, red), modern typography with Google Poppins font
- 📱 **Fully Responsive** – Mobile-first design, tablet and desktop support
- 🛒 **Live Order Summary** – Real-time cart updates with grand total
- 📧 **Automatic Email** – Orders sent to `ddeltaj@gmail.com` via SMTP in the background
- 📱 **M-PESA Integration** – Pochi la Biashara payment with confirmation code verification
- 💬 **WhatsApp Share** – Send order copy to WhatsApp after placing
- 🗄️ **Database** – All orders saved to PostgreSQL via Drizzle ORM
- 🔒 **Security** – Server-side validation, input sanitization, CSRF-safe

---

## 📦 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 16 (App Router), React 19 |
| Styling | Tailwind CSS + Custom CSS |
| Fonts | Google Fonts (Poppins) + Font Awesome |
| Backend | Next.js API Routes (Node.js) |
| Email | Nodemailer (SMTP) |
| Database | PostgreSQL + Drizzle ORM |
| Deployment | Any Node.js host (Vercel, Railway, VPS, etc.) |

---

## ⚙️ Environment Variables

Create a `.env` file in the project root:

```env
# Database
DATABASE_URL=postgresql://user:pass@host:5432/database

# SMTP Email Configuration
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-gmail@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=orders@spanishcafe.co.ke
ORDER_EMAIL=ddeltaj@gmail.com
```

### Setting up Gmail SMTP

1. Go to your Google Account → Security
2. Enable **2-Step Verification**
3. Go to **App passwords** → Create new app password
4. Use the generated 16-character password as `SMTP_PASS`
5. Set `SMTP_USER` to your Gmail address

### Alternative SMTP Providers

| Provider | Host | Port |
|----------|------|------|
| Gmail | smtp.gmail.com | 587 |
| Outlook | smtp.office365.com | 587 |
| Yahoo | smtp.mail.yahoo.com | 587 |
| Zoho | smtp.zoho.com | 587 |
| Brevo (free) | smtp-relay.brevo.com | 587 |
| Mailgun | smtp.mailgun.org | 587 |

---

## 🛠️ Local Development

```bash
# 1. Clone the repository
git clone <repo-url>
cd spanish-cafe

# 2. Install dependencies
npm install

# 3. Set up environment variables
cp .env.example .env
# Edit .env with your credentials

# 4. Set up the database
npx drizzle-kit push

# 5. Start development server
npm run dev
```

Visit `http://localhost:3000`

---

## 🚢 Deployment

### Vercel (Recommended)

```bash
npm install -g vercel
vercel --prod
```

Add all environment variables in the Vercel dashboard.

### Railway

1. Create a new project on [Railway](https://railway.app)
2. Add a PostgreSQL service
3. Deploy from GitHub
4. Set environment variables in Railway dashboard

### VPS / Linux Server

```bash
# Build the app
npm run build

# Start production server
npm start

# Or use PM2
pm2 start npm --name "spanish-cafe" -- start
pm2 save
pm2 startup
```

---

## 📋 Menu Items

| Item | Price |
|------|-------|
| Tea | KSh 20 |
| Mandazi | KSh 10 |
| Ugali | KSh 30 |
| Beans | KSh 50 |
| Sukuma Wiki | KSh 40 |
| Chapati | KSh 20 |
| Eggs | KSh 30 each |
| Kienyeji Eggs | KSh 35 each |
| Chips | KSh 50 |
| Milk (Cup) | KSh 30 |
| Milk (Litre) | KSh 50 |
| Minji Mix | KSh 60 |
| Githeri Mix | KSh 50 |
| Mala | KSh 30/cup |
| Mukimo | KSh 50 |

---

## 📁 Project Structure

```
src/
├── app/
│   ├── api/
│   │   ├── health/route.ts      # Health check endpoint
│   │   └── orders/route.ts      # Order processing + email
│   ├── globals.css              # All custom styles
│   ├── layout.tsx               # Root layout with fonts/meta
│   └── page.tsx                 # Main page (all sections)
├── db/
│   ├── index.ts                 # Drizzle DB connection
│   └── schema.ts                # Orders table schema
└── lib/
    ├── emailTemplate.ts         # HTML email generator
    └── menuItems.ts             # Menu data
```

---

## 📞 Business Info

- **Business:** SPANISH CAFE
- **Phone/WhatsApp:** +254 110 666 172
- **Email:** ddeltaj@gmail.com
- **Payment:** M-PESA – Pochi la Biashara (0713851716)
- **Hours:** Monday–Sunday, 6:00 AM – 10:00 PM

---

## 📝 API Reference

### POST `/api/orders`

Place a new order.

**Request Body:**
```json
{
  "customerName": "John Doe",
  "customerPhone": "+254700000000",
  "customerEmail": "john@email.com",
  "deliveryAddress": "Westlands, Nairobi",
  "tableNumber": "5",
  "orderType": "eat_in | take_away | delivery",
  "paymentMethod": "cash | card | mpesa",
  "preferredDate": "2026-01-15",
  "preferredTime": "12:30",
  "specialInstructions": "Extra spicy please",
  "mpesaConfirmationCode": "QJX7AHG7FP",
  "mpesaAmountPaid": 150,
  "mpesaPaymentDate": "2026-01-15",
  "mpesaPaymentTime": "12:00",
  "mpesaPaid": true,
  "items": [
    { "id": "tea", "name": "Tea", "price": 20, "quantity": 2, "subtotal": 40 }
  ]
}
```

**Success Response:**
```json
{
  "success": true,
  "message": "Order placed successfully!",
  "orderNumber": "SC-ABC123-XYZ",
  "grandTotal": 40,
  "whatsappUrl": "https://wa.me/254110666172?text=...",
  "emailSent": true
}
```

**Error Response:**
```json
{
  "success": false,
  "message": "Customer name is required."
}
```

---

© 2026 SPANISH CAFE – Serving Fresh Food Every Day ❤️
